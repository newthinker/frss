//>>built
define(
"dijit/form/nls/pt/ComboBox", //begin v1.x content
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
//end v1.x content
);
