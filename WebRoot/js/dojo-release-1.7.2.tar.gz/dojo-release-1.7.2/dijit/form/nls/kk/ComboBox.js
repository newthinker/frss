//>>built
define(
"dijit/form/nls/kk/ComboBox", //begin v1.x content
({
		previousMessage: "Алдыңғы нұсқалар",
		nextMessage: "Басқа нұсқалар"
})
//end v1.x content
);

