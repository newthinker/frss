//>>built
define(
"dijit/form/nls/ar/validate", //begin v1.x content
({
	invalidMessage: "القيمة التي تم ادخالها غير صحيحة.",
	missingMessage: "يجب ادخال هذه القيمة.",
	rangeMessage: "هذه القيمة ليس بالمدى الصحيح."
})
//end v1.x content
);
