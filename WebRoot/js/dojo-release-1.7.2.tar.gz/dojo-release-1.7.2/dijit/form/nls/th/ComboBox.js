//>>built
define(
"dijit/form/nls/th/ComboBox", //begin v1.x content
({
		previousMessage: "การเลือกก่อนหน้า",
		nextMessage: "การเลือกเพิ่มเติม"
})

//end v1.x content
);
