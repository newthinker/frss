//>>built
define(
"dijit/form/nls/az/ComboBox", //begin v1.x content
({
	"previousMessage" : "Əvvəlki variantlar",
	"nextMessage" : "Başqa variantlar"
})
//end v1.x content
);
