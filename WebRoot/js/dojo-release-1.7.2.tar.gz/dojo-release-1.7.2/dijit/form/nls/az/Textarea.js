//>>built
define(
"dijit/form/nls/az/Textarea", //begin v1.x content
({
	"iframeEditTitle" : "Redaktə sahəsi",
	"iframeFocusTitle" : "Redaktə sahəsi çərçivəsi"
})
//end v1.x content
);
