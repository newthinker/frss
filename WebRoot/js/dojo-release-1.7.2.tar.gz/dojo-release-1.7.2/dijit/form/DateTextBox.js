//>>built
define("dijit/form/DateTextBox",["dojo/_base/declare","../Calendar","./_DateTimeTextBox"],function(_1,_2,_3){
return _1("dijit.form.DateTextBox",_3,{baseClass:"dijitTextBox dijitComboBox dijitDateTextBox",popupClass:_2,_selector:"date",value:new Date("")});
});
