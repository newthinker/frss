//>>built
define(
"dijit/nls/fi/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Peruuta",
	buttonSave: "Tallenna",
	itemClose: "Sulje"
})
//end v1.x content
);
