//>>built
define(
"dijit/nls/pt-pt/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Fechar"
})
//end v1.x content
);
