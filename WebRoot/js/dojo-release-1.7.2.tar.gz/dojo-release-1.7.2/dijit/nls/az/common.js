//>>built
define(
"dijit/nls/az/common", //begin v1.x content
({
	"buttonOk" : "Ok",
	"buttonCancel" : "Ləğv et",
	"buttonSave" : "Saxla",
	"itemClose" : "Bağla"
})
//end v1.x content
);
