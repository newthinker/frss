//>>built
define(
"dijit/nls/hu/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Mégse",
	buttonSave: "Mentés",
	itemClose: "Bezárás"
})
//end v1.x content
);
