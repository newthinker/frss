//>>built
define(
"dijit/nls/hu/loading", //begin v1.x content
({
	loadingState: "Betöltés...",
	errorState: "Sajnálom, hiba történt"
})
//end v1.x content
);
