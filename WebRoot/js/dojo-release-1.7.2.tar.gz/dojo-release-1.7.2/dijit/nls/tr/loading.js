//>>built
define(
"dijit/nls/tr/loading", //begin v1.x content
({
	loadingState: "Yükleniyor...",
	errorState: "Üzgünüz, bir hata oluştu"
})
//end v1.x content
);
