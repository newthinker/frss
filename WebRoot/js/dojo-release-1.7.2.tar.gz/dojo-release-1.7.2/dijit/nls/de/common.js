//>>built
define(
"dijit/nls/de/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Abbrechen",
	buttonSave: "Speichern",
	itemClose: "Schließen"
})
//end v1.x content
);
