//>>built
define(
"dijit/nls/de/loading", //begin v1.x content
({
	loadingState: "Wird geladen...",
	errorState: "Es ist ein Fehler aufgetreten."
})
//end v1.x content
);
